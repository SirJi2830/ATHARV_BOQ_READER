package com.atharv.boqreader

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

data class BoqItem(
    val sheet: String, val itemNo: String, val description: String,
    val quantity: String, val unit: String, val rate: String, val amount: String
)

data class ReadResult(val filename: String, val text: String, val items: List<BoqItem>, val warnings: List<String>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { BoqScreen(this) }
    }
}

@Composable
fun BoqScreen(context: Context) {
    var result by remember { mutableStateOf<ReadResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            busy = true; error = ""
            (context as? ComponentActivity)?.lifecycleScope?.launch {
                try { result = withContext(Dispatchers.IO) { BoqReader.read(context, uri) } }
                catch (e: Exception) { error = e.message ?: "File could not be read." }
                finally { busy = false }
            }
        }
    }
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Atharv Enterprises BOQ Reader") }) }) { pad ->
            Column(Modifier.padding(pad).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Read BOQ files and extract item-wise quantities, rates and amounts.", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                    Text("Choose BOQ File")
                }
                if (busy) CircularProgressIndicator()
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                result?.let { r ->
                    Text(r.filename, style = MaterialTheme.typography.titleMedium)
                    Text("Extracted items: ${r.items.size}")
                    val total = r.items.mapNotNull { it.amount.replace(",", "").replace("₹", "").trim().toDoubleOrNull() }.sum()
                    Text("Recognized amount total: ₹${"%,.2f".format(Locale("en", "IN"), total)}")
                    if (r.warnings.isNotEmpty()) {
                        Text("Review notes", style = MaterialTheme.typography.titleSmall)
                        r.warnings.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(r.items) { item ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Text("${item.itemNo}  ${item.description}", style = MaterialTheme.typography.titleSmall)
                                    Text("Qty: ${item.quantity} ${item.unit} | Rate: ${item.rate} | Amount: ${item.amount}")
                                    Text("Sheet: ${item.sheet}", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    if (r.items.isEmpty()) {
                        Text("No standard item table was detected. Extracted text is available for review in the raw-text section.")
                    }
                    var expanded by remember { mutableStateOf(false) }
                    TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Hide extracted text" else "Show extracted text") }
                    if (expanded) Text(r.text.take(12000), style = MaterialTheme.typography.bodySmall)
                }
                Text("Supported in this starter: XLS, XLSX, XLSM (cached values), CSV, TSV, TXT and text-based PDF. Scanned PDF/image OCR and online enhancement are planned modules.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

object BoqReader {
    fun read(context: Context, uri: Uri): ReadResult {
        val name = queryName(context, uri)
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val warnings = mutableListOf<String>()
        val text = when (ext) {
            "xls", "xlsx", "xlsm" -> readExcel(context, uri, warnings)
            "csv", "tsv", "txt" -> context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            "pdf" -> readPdf(context, uri)
            else -> {
                warnings += "Unsupported or unverified file type: .$ext. Try exporting it as XLSX, CSV or searchable PDF."
                context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            }
        }
        val items = extractItems(text, warnings)
        if (ext == "xlsm") warnings += "VBA macros are not executed. Only values stored in the workbook (including cached formula results where available) are read."
        if (ext == "pdf") warnings += "Scanned/image-only PDFs need OCR; this starter currently extracts selectable PDF text."
        return ReadResult(name, text, items, warnings.distinct())
    }

    private fun queryName(c: Context, uri: Uri): String {
        var n = "BOQ file"
        c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                val idx = cur.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) n = cur.getString(idx) ?: n
            }
        }
        return n
    }

    private fun readExcel(c: Context, uri: Uri, warnings: MutableList<String>): String {
        val out = StringBuilder()
        c.contentResolver.openInputStream(uri).use { input ->
            val wb = WorkbookFactory.create(input)
            val fmt = DataFormatter()
            for (s in 0 until wb.numberOfSheets) {
                val sheet = wb.getSheetAt(s)
                out.append("\n[SHEET: ${sheet.sheetName}]\n")
                if (sheet.sheetState != org.apache.poi.ss.usermodel.SheetVisibility.VISIBLE) warnings += "Hidden sheet found: ${sheet.sheetName}"
                for (row in sheet) {
                    val cells = (0 until maxOf(row.lastCellNum.toInt(), 0)).map { i ->
                        fmt.formatCellValue(row.getCell(i)).replace("\t", " ").replace("\n", " ").trim()
                    }
                    if (cells.any { it.isNotBlank() }) out.append(cells.joinToString("\t")).append('\n')
                }
            }
            wb.close()
        }
        return out.toString()
    }

    private fun readPdf(c: Context, uri: Uri): String {
        val doc = c.contentResolver.openInputStream(uri).use { PDDocument.load(it) }
        return try { PDFTextStripper().getText(doc) } finally { doc.close() }
    }

    private fun extractItems(raw: String, warnings: MutableList<String>): List<BoqItem> {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }
        val out = mutableListOf<BoqItem>()
        var sheet = "Document"
        var header: List<String> = emptyList()
        var idx = 0
        while (idx < lines.size) {
            val line = lines[idx]
            if (line.startsWith("[SHEET:")) sheet = line.removePrefix("[SHEET:").removeSuffix("]").trim()
            val cells = line.split('\t').map { it.trim() }
            val normalized = cells.map { it.lowercase(Locale.ROOT).replace(Regex("[^a-z]"), "") }
            if (normalized.any { it.contains("description") || it == "itemname" } &&
                normalized.any { it.contains("quantity") || it == "qty" } &&
                normalized.any { it.contains("rate") || it.contains("amount") }) {
                header = normalized
            } else if (header.isNotEmpty() && cells.size >= 3) {
                fun find(vararg keys: String): String {
                    val pos = header.indexOfFirst { h -> keys.any { h.contains(it) } }
                    return if (pos in cells.indices) cells[pos] else ""
                }
                val desc = find("description", "itemname", "particular")
                val qty = find("quantity", "qty")
                val unit = find("unit")
                val rate = find("rate")
                val amount = find("amount", "total")
                val itemNo = find("itemno", "itemnumber", "srno", "sno", "slno")
                if (desc.isNotBlank() && (qty.isNotBlank() || amount.isNotBlank())) {
                    out += BoqItem(sheet, itemNo.ifBlank { (out.size + 1).toString() }, desc, qty, unit, rate, amount)
                } else if (cells.any { it.contains("description", true) }) {
                    warnings += "Possible item table near line ${idx + 1} needs manual review."
                }
            }
            idx++
        }
        if (out.isEmpty()) warnings += "No table with recognizable Description + Quantity + Rate/Amount headers was found. Different PWD templates may need a custom mapping."
        return out
    }
}
